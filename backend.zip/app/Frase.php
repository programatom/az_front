<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Frase extends Model
{
  protected $fillable =
  [
    'frase',
    'frase_id',
  ];
}
