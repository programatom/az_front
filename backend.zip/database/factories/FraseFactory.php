<?php

use Faker\Generator as Faker;

$factory->define(App\Frase::class, function (Faker $faker) {
    return [
        //
    ];
});
