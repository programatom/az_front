<?php

use Faker\Generator as Faker;

$factory->define(App\Palabra::class, function (Faker $faker) {
    return [
        //
    ];
});
