<?php

use Faker\Generator as Faker;

$factory->define(App\FraseEstructura::class, function (Faker $faker) {
    return [
        //
    ];
});
